#include <stdio.h>

int main()
{
    //definicao de variavel
    float idade;
    //pergunta pro usuario
    printf("Digite sua idade: ");
    scanf("%f", &idade);
    //se idade for maior ou igual a 18, demonstra que o usuario é maior
    //de idade. caso contrario, menor de idade
    if (idade>=18)
    {
        printf("Você é maior de idade.");
    } else {
        printf("Você é menor de idade.");
    }
}