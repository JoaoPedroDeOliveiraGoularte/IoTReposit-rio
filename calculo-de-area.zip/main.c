#include <stdio.h>
#define PI 3.14159

int main()
{
    //definicao de variaveis
    float n1, n2, calculo;
    //demonstracao pro usuario
    printf("Digite um valor: ");
    scanf("%f", &n1);
    printf("Digite outro valor: ");
    scanf("%f", &n2);
    //calculo necessario
    calculo = n1+n2;
    //se o calculo for maior que 10, é demonstrado pro usuario
    //caso contrario, ha uma mensagem de erro
    if (calculo>10)
    {
        printf("Seu número é maior que dez. Número: %f", calculo);
    } else {
        printf("Erro.");
    }
    return 0;
}