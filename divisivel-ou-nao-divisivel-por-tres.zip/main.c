#include <stdio.h>

int main()
{
    //definicao de variavel
    int numero;
    //demonstracao pro usuario
    printf("Digite um número para ver se ele é divisível por 3: ");
    scanf("%d", &numero);
    //se o resto da divisao for 0, é dito que o numero é divisivel por 3.
    //caso contrario, nao é divisivel por 3
    if (numero%3==0)
    {
        numero++;
        printf("É divisível por três. Número atualizado: %d",  numero);
    } else {
        numero--;
        printf("Não é divisível por três. Número atualizado: %d",  numero);
    }
}