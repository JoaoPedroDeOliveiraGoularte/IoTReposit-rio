#include <stdio.h>

int main()
{
    //definicao de variaveis
    float salario, desconto1, desconto2, desconto3;
    //demonstracao pro usuario
    printf("Digite seu salário: R$");
    scanf("%f", &salario);
    //se o salario for menor ou igual, e maior a tal, o calculo é feito
    if (salario<=600)
    {
        printf("Salário: %f", salario);
    } else if (salario<=1200 && salario>600)
    {
        desconto1=salario-(salario*20/100);
        printf("Salário: %f", desconto1);
    } else if (salario<=2000 && salario>1200)
    {
        desconto2=salario-(salario*25/100);
        printf("Salário: %f", desconto2);
    } else if (salario>2000)
    {
        desconto3=salario-(salario*30/100);
        printf("Salário: %f", desconto3);
    }
}